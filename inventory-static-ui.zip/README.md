# Inventory BPA — Static UI Demo (Phase 1)

This is a static single-page React build for client review. There is **no backend** — every interaction uses in-memory mocks and resets on page refresh.

## Deploy to cPanel

1. Log in to cPanel → **File Manager**.
2. Navigate to `public_html/` (root deploy) or a sub-folder like `public_html/demo/` (sub-path deploy).
3. Click **Upload** → upload the `inventory-static-ui.zip` archive.
4. Right-click the archive → **Extract** → into the same folder. Delete the archive after.
5. Make sure the `.htaccess` file came across (toggle "Show hidden files" in File Manager settings if needed).
6. Visit the URL. Refresh on any deep link should still work — `.htaccess` rewrites it to `index.html`.

### Sub-folder hosting (e.g. `/demo/`)

If you are hosting under a sub-path:

1. Open `.htaccess` in the deploy folder.
2. Uncomment the line `# RewriteBase /demo/` and set it to your folder name.
3. Re-build the bundle with `VITE_BASE_PATH=/demo/ npm run build` so asset URLs are prefixed correctly. (Re-zip and re-upload.)

### Force HTTPS

After your SSL cert is active in cPanel, uncomment Section 2 in `.htaccess` to redirect HTTP → HTTPS.

## What's inside

- `index.html` — SPA shell.
- `assets/` — hashed JS/CSS chunks plus pre-compressed `.gz` and `.br` siblings (Apache will serve those automatically when the browser sends `Accept-Encoding`).
- `favicon.svg`, `icons.svg` — icon assets.
- `.htaccess` — SPA fallback + compression + cache + security headers.

## Demo credentials

The app is pre-signed-in as a demo administrator — there is no real auth. Click around freely; nothing persists.

## Known limits (Phase 1, by design)

- All data is mocked (quotations, orders, inventory, dispatch, jobs, documents, reports, approvals, etc.).
- Refresh discards any edits.
- Exports show a toast but do not produce real files.
- Approvals decisions reflect in the inbox only — per-detail banners do not yet sync (this lands when the API is wired in Phase 2).

Phase 2 (backend API) and Phase 3 (full integration + auth) follow this review.
